
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proejkt;

/**
 *
 * @author Admin
 */
       import java.io.File;
 import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
 import java.util.Scanner;

public class Proejkt {
    

    /**
     * @param trasa
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
      
         
         File f = new File("C:/Users/Admin/Desktop/projekt java/trasa1.txt");
         Scanner in = new Scanner(f);
 
         
     
        
         String startxx = in.nextLine();
         String startyx = in.nextLine();
         String endxx = in.nextLine();
         String endyx = in.nextLine();
         String maxkx = in.nextLine();
         String maxwx = in.nextLine();
         int startx = Integer.valueOf(startxx);
         int starty = Integer.valueOf(startyx);
         int endx = Integer.valueOf(endxx);
         int endy = Integer.valueOf(endyx);
         int maxk = Integer.valueOf(maxkx);
         int maxw = Integer.valueOf(maxwx);
      
         List<String> lod = new ArrayList<String>();
         int czysk=0;
    
        char[][]siatka=new char[maxw][maxk];
            
             String[][] siatka2 = new String[maxw][maxk];
            for (int i = 0; i < maxw; i++) {
                String lin=in.nextLine();
                lin=lin.trim();
                 System.out.println(lin);
                 int jj=0;
                for (int j = 0; j < maxk; j++) {
                  
                    
                    siatka[i][j]=lin.charAt(jj);
                    jj=jj+2;
      
                }
                    
            
             }  
            

 
   
    List<punkt> tabp = new ArrayList<punkt>();
    List<punkt> listapdr = new ArrayList<punkt>();
    int id=0;

     if(siatka[startx][starty]== '1' || siatka[endx][endy]== '1')
     {
         System.out.println("nie");
          czysk=1;
        }
    
   siatka[startx][starty] = '#';
    siatka[endx][endy] = '#';
    punkt z =new punkt();

    z.tworzepunkt(startx, starty, id);
    id = 1;
    punkt mm =new punkt();
    mm.tworzepunkt(endx, endy, id);
  
    tabp.add(z);
    tabp.add(mm);
    listapdr.add(z);
    punkt biezacyp=new punkt();
    punkt kok = null;
    punkt bok;
    
     while(listapdr.isEmpty()==false)
{
        biezacyp = listapdr.get(0);
        int  w = biezacyp.x;
        int k = biezacyp.y;

       
         
        id =tabp.size();
        if(k > 0 && siatka[w][k-1] =='0'){
          
            ruch(w, k-1, "l", id, siatka, listapdr, biezacyp, tabp,maxk,maxw);}
        else{
              
            if (k > 0 && siatka[w][k-1] == '#'){
                int qwe = 0;
 punkt hip = null ;
                for (int po=0;po<tabp.size();po++){
                   
                    kok=tabp.get(po);
                    if (kok.czytopunkt(w, k-1)== 1){
                        hip=kok;
                        break;}}
                List<Integer> nom=hip.sasiad;
                int hmi=nom.indexOf(biezacyp.id);
                if(hmi==-1){
                    biezacyp.tworzenierelacji(biezacyp,1, kok, "l");}}}
        id = tabp.size();
    
        if(k < maxk-1 && siatka[w][k+1] == '0'){
            
            ruch(w, k+1, "p", id, siatka, listapdr, biezacyp, tabp,maxk,maxw);}
        else{
            if (k <maxk-1 && siatka[w][k+1] == '#'){
                punkt hip = null;
                int qwe = 0;
                for (int po=0;po<tabp.size();po++){
                   
                    kok=tabp.get(po);
                    if (kok.czytopunkt(w, k+1)== 1){
                        hip=kok;
                        break;}}
                  List<Integer> nom=hip.sasiad;
                int hmi=nom.indexOf(biezacyp.id);
                if(hmi==-1){
                    biezacyp.tworzenierelacji(biezacyp,1, kok, "p");}}}
        id = tabp.size();
        
         

        if(w < maxw-1 && siatka[w+1][k] == '0'){
          
            ruch(w+1, k, "d", id, siatka, listapdr, biezacyp, tabp,maxk,maxw);}
        else{
            if (w <maxw-1 && siatka[w+1][k] == '#'){
                int qwe = 0;
                 punkt hip = null;
                for (int po=0;po<tabp.size();po++){
                   
                    kok=tabp.get(po);
                    if (kok.czytopunkt(w+1, k)== 1){
                        hip=kok;
                        break;}}
                        List<Integer> nom=hip.sasiad;
                int hmi=nom.indexOf(biezacyp.id);
                if(hmi==-1){
                    biezacyp.tworzenierelacji(biezacyp,1, kok, "d");}}}
        
         id = tabp.size();
           
        if(w > 0 && siatka[w-1][k] == '0'){
            ruch(w-1, k, "g", id, siatka, listapdr, biezacyp, tabp,maxk,maxw);}
        else{
            if (w>0 && siatka[w-1][k] == '#'){
                int qwe = 0;
                 punkt hip = null;
                for (int po=0;po<tabp.size();po++){
                   
                    kok=tabp.get(po);
                    if (kok.czytopunkt(w-1, k)== 1){
                        hip=kok;
                        break;}}
            List<Integer> nom=hip.sasiad;
                int hmi=nom.indexOf(biezacyp.id);
                if(hmi==-1){
                    biezacyp.tworzenierelacji(biezacyp,1, kok, "g");}}}
          
        int gg = biezacyp.id;
     
        listapdr.remove(0);
     
         
    
    }int gmo=0;
    for(punkt jp:tabp)
    {System.out.println(gmo);
    System.out.println(jp.kierunek);
    System.out.println(jp.sasiad);
    gmo+=1;
    }
    List<Integer> trasa = new ArrayList<Integer>();
    int n=tabp.size();
  
     int dlll = rekr(tabp.get(1), "w", 0, tabp, trasa,lod);

    if(dlll ==Integer.MAX_VALUE || czysk == 1)
        System.out.println("nie ma drogi");
    else{
       System.out.println("dlugosc trasy:");
      
        dlll = dlll+1;
        System.out.println(dlll);
        
        for(String mn:lod){
     
            List<Integer> ted =new ArrayList<Integer>();
            for(int hjj=0;hjj<mn.length();hjj++){
                char D=mn.charAt(hjj);
                if(D != ',' && D != '[' && D != ']' && D != ' ')
                { int lk=Character.getNumericValue(D);
                    ted.add(lk);}}
            int dod=0;
            int czy = 1;
            int mk=0;
            for(int wer=0;wer<ted.size()-1;wer++){
                int e = ted.get(wer);
                int ed = ted.get(wer+1);
                punkt m=tabp.get(e);
         
                for(int cv=0;cv<m.sasiad.size();cv++)
                {  if(m.sasiad.get(cv) == ed){
                    mk=cv;    
                    break;}}
                dod += m.dystans.get(mk);
                if(dod > dlll){
                    czy = 0;
                    break;}}
            if(czy == 1)
                trasa = ted;
                        }
        punkt hy=tabp.get(0);
        String abc=String.valueOf(hy.x);
        String bcd=String.valueOf(hy.y);
        System.out.println(abc+","+bcd);
        for(int yup=0;yup<trasa.size()-1;yup++){
           int mym=trasa.get(yup);
           int a = tabp.get(mym).x;
           int b = tabp.get(mym).y;
           int hmm=trasa.get(yup+1);
           int c = tabp.get(hmm).x;
            int d = tabp.get(hmm).y;
 
            while(a != c || b != d){
                if(a > c)
                    a -= 1;
                else{
                    if(b > d)
                        b -= 1;
                    else{
                        if(a < c)
                            a += 1;
                       else{
                            if(b < d)
                                b += 1;}}}
        String abcd=String.valueOf(a);
        String bcdd=String.valueOf(b);
        System.out.println(abcd+","+bcdd);              
     
    
                        }}}
    }

    private static void jdd(List<String> lod, List<Integer> trasa) {
            String hmh="";
        
        for(int i:trasa)
        { hmh+=Integer.toString(i)+",";
    
            
        
        }
        System.out.println(hmh);
        lod.add(hmh); //To change body of generated methods, choose Tools | Templates.
    }
  
    


     public static void ruch(int w,int k,String kier,int id,char[][] siatka,List<punkt> listapdr,punkt biezacyp,List<punkt> tabp,int maxk,int maxw){
        int q = 0;
        int i = w;
        int j = k;

        int dist = 1;
        if(kier == "l" || kier == "p"){
            while (q == 0){

                if(siatka[w][j] == '0'){
                    siatka[w][j] = '2';}
                else{
                    break;}
                if(kier == "l" && j == 0){
                    break;}
                if(kier == "p" && j == maxk-1){
                    break;}
                if(w > 0 && siatka[w-1][j] != '1'){
                    break;}
                if(w < maxw-1 && siatka[w+1][j] !='1'){
                    break;}

                if(kier == "l"){
                    if (siatka[w][j-1] != '1')
                    {j -= 1;}
                    else
                    {break;}}
                else{
                    if (siatka[w][j+1] != '1')
                        j += 1;
                    else{
                        break;}}}}
         if(kier == "g" || kier == "d"){
            while (q == 0){

                if(siatka[w][j] == '0'){
                    siatka[w][j] = '2';}
                else{
                    break;}
                if(kier == "g" && i == 0){
                    break;}
                if(kier == "d" && i == maxw-1){
                    break;}
                if(k > 0 && siatka[i][k-1] != '1'){
                    break;}
                if(k < maxk-1 && siatka[i][k+1] != '1'){
                    break;}

                if(kier == "g"){
                    if (siatka[i-1][k] != '1')
                    {i -= 1;}
                    else
                    {break;}}
                else{
                    if (siatka[i+1][k] != '1')
                        i += 1;
                    else{
                        break;}}}}
            
            
            
            
            
        
        dist = Math.abs(w-i+k-j)+1;
        if(siatka[i][j] == '#'){
            for(int po=0;po<tabp.size();po++)
            {punkt kok=new punkt();
            kok=tabp.get(po);
                 if (kok.czytopunkt(i, j) == 1)
            {List<Integer> nom=kok.sasiad;
                int hmi=nom.indexOf(biezacyp.id);
                if(hmi==-1)
                biezacyp.tworzenierelacji(biezacyp,dist, kok, kier);
                  break;}}}
         else{
            siatka[i][j] = '#';
            punkt c =new punkt();
            c.tworzepunkt(i, j, id);
            biezacyp.tworzenierelacji(biezacyp,dist, c, kier);
            tabp.add(c);
            listapdr.add(c);
                    } 
}
    protected static int rekr(punkt punkt,String kier,int szukana,List<punkt> tabp,List<Integer> trasa, List<String>lod){
        int ui = 3;
        int look=0;
        trasa.add(0, punkt.id);
  
        List<Integer> p = new ArrayList<Integer>();
        List<String> k = new ArrayList<String>();
        int dyd=0;
        int klo = punkt.id;
        punkt dydyd=tabp.get(klo);
        dydyd.odwiedzony += 1;
        int tta=0;
        punkt hub=tabp.get(0);
        int cod=0;
        String  zer = "0";
        if (kier != "w"){
            if(kier == "l")
                zer = "p";
            if(kier == "p")
                zer = "l";
            if(kier == "g")
                zer = "d";
            if(kier == "d")
                zer = "g";
           
            for(int r=0;r<punkt.sasiad.size();r++){
                if (dydyd.kierunek.get(r) == zer)
                { tta=r;
                    break;}}
         
            cod = dydyd.sasiad.get(tta);
             hub=tabp.get(cod);
           
            for(int de=0;de<hub.sasiad.size();de++){
                if(hub.kierunek.get(de) == kier)
                {dyd=de;
                    break;}}
                     System.out.println(trasa); 
            punkt zero=tabp.get(0);
            if(punkt.x == zero.x && punkt.y == zero.y)
            {List<Integer> co = trasa;
                jdd(lod,trasa);
                return punkt.dystans.get(tta);
                        }
            if(punkt.sasiad.size() < 2){
                hub.kierunek.set(dyd,"m");
                if (trasa.size() > 0)
                { trasa.remove(0);
                look=1;}
                return -1;
                        }

            for(int i=0;i<punkt.sasiad.size();i++){
                if(kier == "l"){
                    if(punkt.kierunek.get(i) == "l" || punkt.kierunek.get(i) == "d")
                    {int mmmm=punkt.sasiad.get(i);
                        punkt hmh=tabp.get(mmmm);    
                        if(hmh.odwiedzony < ui && punkt.sasiad.get(i)!= 1)
                        {  p.add(punkt.sasiad.get(i));
                            k.add(punkt.kierunek.get(i));
                                    }}}
                if(kier == "d"){
                    if(punkt.kierunek.get(i) == "p" || punkt.kierunek.get(i) == "d")
                    {int mmmm=punkt.sasiad.get(i);
                        punkt hmh=tabp.get(mmmm);    
                        if(hmh.odwiedzony < ui && punkt.sasiad.get(i)!= 1)
                        {  p.add(punkt.sasiad.get(i));
                            k.add(punkt.kierunek.get(i));
                                    }}}
                if(kier == "g"){
                    if(punkt.kierunek.get(i) == "g" || punkt.kierunek.get(i) == "l")
                    {int mmmm=punkt.sasiad.get(i);
                        punkt hmh=tabp.get(mmmm);    
                        if(hmh.odwiedzony < ui && punkt.sasiad.get(i)!= 1)
                        {  p.add(punkt.sasiad.get(i));
                            k.add(punkt.kierunek.get(i));}}}
                 if(kier == "p"){
                    if(punkt.kierunek.get(i) == "g" || punkt.kierunek.get(i) == "p")
                    {int cccc=punkt.sasiad.get(i);
                        punkt hmhh=tabp.get(cccc);    
                        if(hmhh.odwiedzony < ui && punkt.sasiad.get(i)!= 1)
                        {  p.add(punkt.sasiad.get(i));
                            k.add(punkt.kierunek.get(i));
                                    }}}
        
           
                                    }
          
        tabp.set(cod, hub);
         tabp.set(klo, dydyd);
        
        
        }
        else{
          for(int i=0;i<punkt.sasiad.size();i++){
            p.add(punkt.sasiad.get(i));
            k.add(punkt.kierunek.get(i));}}
          //System.out.println(p); 
        if(p.isEmpty()){
            hub.kierunek.set(dyd,"m");
                  tabp.set(cod, hub);
            if(trasa.size() > 0)
            { trasa.remove(0);
            look=1;}
            return -1;
                    }

        List<Integer>poj = trasa;
      
        int c = 0;
        int min = Integer.MAX_VALUE;
        int pozmin = 0;
        
        
  List<Integer> trasamin=new ArrayList<Integer>();
        for(int i=0;i<p.size();i++){
            trasa = poj;
            
            int dl = rekr(tabp.get(p.get(i)), k.get(i), szukana, tabp, trasa,lod);

            if(dl < min && dl > 0&&look==0){
                min = dl;
                pozmin = i;
                 trasamin = trasa;

                int dlo = 0;
                int t = 0;
                for(int rer:trasa)
                {  dlo=dlo+1;
                    if(rer == klo)
                    { t = 1;
                        break;}
                                }
                if(t == 1)
                {  
                 for(int ided=0;ided<dlo;ided++)
                {  
                    trasa.remove(0);}}
                else{
                    trasa.clear();}
        }}
        //System.out.println(min);

        if(klo == 1)
        {rekr(tabp.get(p.get(pozmin)), k.get(pozmin), szukana, tabp, trasa,lod);
 
           trasa=trasamin;
            return min;}
        else{
            if(min == Integer.MAX_VALUE){
                if(trasa.size()> 0)
                   trasa.remove(0);
                return -1;}
            else{
                return punkt.dystans.get(tta) + min;}}

}}
    
