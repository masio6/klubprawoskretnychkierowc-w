/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proejkt;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
class Int {
String p="123456";
String j=p.substring(1,2);
    
 List<String> lod = new ArrayList<String>();
 lod.add("mym");
}
