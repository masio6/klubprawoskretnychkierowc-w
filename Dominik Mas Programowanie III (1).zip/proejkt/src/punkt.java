
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import static javax.management.Query.and;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class punkt{
                protected int id;
            protected int x;
            protected int y;
    
            protected ArrayList<Integer> sasiad = new ArrayList<Integer>();
            protected ArrayList<Integer> dystans = new ArrayList<Integer>();
            protected ArrayList<String> kierunek = new ArrayList<String>();
          
            protected int odwiedzony;
            

    public void tworzepunkt(int x, int y, int id){
            this.id = id;
            this.x = x;
            this.y = y;
            this.odwiedzony = 0;}

        public void tworzenierelacji(punkt startp,int dyst,punkt endp,String kierunek){
            startp.sasiad.add(endp.id);
            startp.dystans.add(dyst);
            startp.kierunek.add(kierunek);
            endp.sasiad.add(startp.id);
            endp.dystans.add(dyst);}

    public int czytopunkt(int a,int b){
    if(this.y == b && this.x == a){
                return 1;}
            else
            {return 0;}
    }
}
